﻿using Joueur.cs.Games.Newtonian.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using static Joueur.cs.Games.Newtonian.Helpers.Pathfinder;

namespace Joueur.cs.Games.Newtonian
{
    public class NewtonianLogic : UnitLogic<AI, Unit>
    {
        public Player Player => AI.Player;
        public Game Game => AI.Game;
        public Player Opponent => Player.Opponent;
        //public static List<Tile> WaitingRoom;
        public static HashSet<Unit> HelpNeeded = new HashSet<Unit>();
        public static int HelpRange => 10;

        /// <summary>
        /// Material Names in Strings.
        /// </summary>
        public static string[] MaterialName =
        {
            "redium",
            "redium ore",
            "blueium",
            "blueium ore"
        };

        /// <summary>
        /// Possible Materials.
        /// </summary>
        public enum Materials
        {
            Redium,
            RediumOre,
            Blueium,
            BlueiumOre
        }

        public NewtonianLogic(AI ai) : base(ai)
        {
            AddTask(CheckState);

        }

        public bool LashOut(Unit unit)
        {
            if (!CanAct(unit)) return false;
            var tile = unit.Tile.GetNeighbors().FirstOrDefault(t => t.Unit != null && t.Unit.Owner != unit.Owner);
            
            return tile != null && unit.Attack(tile);

        }

        private bool CanAct(Unit unit)
        {
            if (unit.Acted) return false;
            if (unit.StunTime > 0) return false;

            return true;
        }

        public bool CheckState(Unit unit)
        {
            bool needsHelp = false;
            if (unit.Health < unit.PreviousHealth)
                needsHelp = true;
            else if (unit.StunTime > 0)
                needsHelp = true;
            if (HelpNeeded.Contains(unit))
            {
                if (!needsHelp)
                    HelpNeeded.Remove(unit);
            }
            else
                HelpNeeded.Add(unit);

            return false;
        }

        public bool HelpNeighbor(Unit unit)
        {
            Unit help = null;
            if (HelpNeeded.Contains(unit)) return false;
            foreach (var needy in HelpNeeded)
            {
                if (!(needy.Tile.GetDistance(unit.Tile) <= HelpRange)) continue;
                if (help == null)
                    help = needy;
                else if (unit.Tile.GetDistance(help.Tile) > needy.Tile.GetDistance(unit.Tile))
                    help = needy;
            }

            if (help == null)
            {
                return false;
            }

            unit.Target = help.Tile.GetNeighbors().FirstOrDefault(t => t.Unit != null && t.Unit.Owner != help.Owner);

            if (unit.Target != null)
            {
                return false;
            }

            return Attack(unit);
        }

        /// <summary>
        /// Action to gather resources from the map.
        /// </summary>
        /// <param name="unit">Unit to Compete the action.</param>
        /// <returns>True if action was successfully attempted, false if it wasn't possible to try.</returns>
        public bool GatherMaterial(Unit unit)
        {
            if (!CanAct(unit))
                return false;
            if (unit.MaterialAmount >= unit.Job.CarryLimit)
                return false;
            switch (unit.LogicJob)
            {
                case Unit.LogicJobs.MaterialCollector:
                    unit.Target = Game.Machines.FirstOrDefault(m => m.Tile.Redium > 0 || m.Tile.Blueium > 0)?.Tile;
                    break;
                case Unit.LogicJobs.RediumProcessor:
                    unit.Target = Game.Tiles.FirstOrDefault(t => (t.RediumOre > 0 && t.Machine == null && t.Unit == null) | t.Redium > 0);
                    break;
                
                case Unit.LogicJobs.BlueiumProcessor:
                    unit.Target = Game.Tiles.FirstOrDefault(t => (t.BlueiumOre > 0 && t.Machine == null && t.Unit == null) | t.Blueium > 0);
                    break;
                case Unit.LogicJobs.RedOreCollector:
                    unit.Target = Game.Tiles.FirstOrDefault(t => t.RediumOre > 0 && t.Machine == null && t.Unit == null);
                    break;
                case Unit.LogicJobs.BlueOreCollector:
                    unit.Target = Game.Tiles.FirstOrDefault(t => t.BlueiumOre > 0 && t.Machine == null && t.Unit == null);
                    break;
            }

            if (unit.Target == null) return false;

            if (Move(unit))
            {
                if (unit.LogicJob == Unit.LogicJobs.BlueiumProcessor)
                {
                    unit.Pickup(unit.Target, 0, MaterialName[unit.Target.Blueium > 0
                        ? (int) Materials.Blueium
                        : (int) Materials.BlueiumOre]);
                }
                else if (unit.LogicJob == Unit.LogicJobs.RediumProcessor)
                {
                    unit.Pickup(unit.Target, 0, MaterialName[unit.Target.Redium > 0
                        ? (int) Materials.Redium
                        : (int) Materials.RediumOre]);
                }
                else
                {
                    unit.Pickup(unit.Target, 0,
                        MaterialName[
                            unit.LogicJob == Unit.LogicJobs.BlueOreCollector
                                ? (int) Materials.BlueiumOre
                                : unit.LogicJob == Unit.LogicJobs.RedOreCollector
                                    ? (int) Materials.RediumOre
                                    : unit.Target?.Redium > 0 
                                        ? (int) Materials.Redium 
                                        : (int) Materials.Blueium]);
                }
            }
             
            return true;
        }


        /// <summary>
        /// Action to get unit away from spawn to not block the way.
        /// </summary>
        /// <param name="unit">Unit to Compete the action.</param>
        /// <returns>True if action was successfully attempted, false if it wasn't possible to try.</returns>
        public bool GetOutOfSpawn(Unit unit)
        {
            if (!CanAct(unit))
                return true;
            if (unit.Tile.Type != "spawn")
            {
                return false;
            }
            // TODO: Implement waiting rooms.
            unit.Target = Game.GetTileAt(Game.MapWidth / 2, Game.MapHeight / 2);
            
            if (unit.Target == null) return true;

            return Move(unit);
        }

        /// <summary>
        /// Action to Fill the nearest machine with ores.
        /// </summary>
        /// <param name="unit">Unit to Compete the action.</param>
        /// <returns>True if action was successfully attempted, false if it wasn't possible to try.</returns>
        public bool FillMachine(Unit unit)
        {
            if (!CanAct(unit)) return false;

            if (unit.MaterialAmount <= 0) return false;

            if (unit.MaterialAmount != unit.Job.CarryLimit) return false;

            switch (unit.LogicJob)
            {
                case Unit.LogicJobs.RedOreCollector:
                    unit.Target = Game.Machines.FirstOrDefault(m => m.OreType == "redium")?.Tile;
                    break;
                case Unit.LogicJobs.BlueOreCollector:
                    unit.Target = Game.Machines.FirstOrDefault(m => m.OreType == "blueium")?.Tile;
                    break;
            }

            if (unit.Target == null) return false;


            if (Move(unit))
                unit.Drop(unit.Target, 0,
                    unit.LogicJob == Unit.LogicJobs.BlueOreCollector
                        ? MaterialName[(int) Materials.BlueiumOre]
                        : MaterialName[(int) Materials.RediumOre]);
            else return false;
            return true;


        }

        /// <summary>
        /// Action to step away from any machine the unit is blocking.
        /// </summary>
        /// <param name="unit">Unit to Compete the action.</param>
        /// <returns>True if action was successfully attempted, false if it wasn't possible to try.</returns>
        public bool StepAway(Unit unit)
        {
            if (!CanAct(unit)) return false;
            if (unit.Moves == 0) return false;

            Tile gen = unit.Tile.GetNeighbors().FirstOrDefault(t => t.Machine == null && !t.IsWall && t.Unit == null);

            if (gen == null) return false;
            return unit.Move(gen);

        }

        /// <summary>
        /// Action to Operate Machine to create refined Material.
        /// </summary>
        /// <param name="unit">Unit to Compete the action.</param>
        /// <returns>True if action was successfully attempted, false if it wasn't possible to try.</returns>
        public bool OperateMachine(Unit unit)
        {
            if (!CanAct(unit)) return false;
            if (unit.Moves == 0) return false;

            switch (unit.LogicJob)
            {
                case Unit.LogicJobs.RediumProcessor:
                    unit.Target = Game.Machines.FirstOrDefault(m => m.OreType == "redium" && m.Tile.RediumOre >= m.RefineInput)?.Tile;
                    break;
                case Unit.LogicJobs.BlueiumProcessor:
                    unit.Target = Game.Machines.FirstOrDefault(m => m.OreType == "blueium" && m.Tile.BlueiumOre >= m.RefineInput)?.Tile;
                    break;
            }

            if (unit.Target == null) return false;
            
            if (unit.Acted) return false;

            if (Move(unit))
            {
                unit.Act(unit.Target);
            }

            return true;

        }

        /// <summary>
        /// Action to Devliver to a Generator
        /// </summary>
        /// <param name="unit">Unit to complete action.</param>
        /// <returns>True if Action was successfully attempted, false if it wasn't possible to try.</returns>
        public bool DeliverToGenerator(Unit unit)
        {
            if (!CanAct(unit))
                return false;
            if (unit.Blueium <= 0 && unit.Redium <= 0)
                return false;
            if (unit.Blueium + unit.Redium != unit.Job.CarryLimit) return false;

            unit.Target = Player.GeneratorTiles.FirstOrDefault(u => u.Unit == null);

            if (unit.Target == null) return false;

            if (Move(unit))
            {
                if (unit.Redium > 0) unit.Drop(unit.Target, 0, "redium");
                if (unit.Blueium > 0) unit.Drop(unit.Target, 0, "blueium");
            }
            return true;
        }

        /// <summary>
        /// Action to set a Unit's Logic Job.
        /// </summary>
        /// <param name="unit">Unit to be set.</param>
        /// <returns>True if job was set.</returns>
        public static bool SetJob(Unit unit)
        {
            var jobCount = new int[Unit.NumLogicJobs];
            if (unit.Owner?.Units != null)
                foreach (var playerUnit in unit.Owner?.Units)
                {
                    jobCount[(int) playerUnit.LogicJob]++;
                }
            else return false;

            switch (unit.Job.Title)
            {
                case "intern":
                    jobCount[(int)unit.LogicJob]--;
                    if (jobCount[(int)Unit.LogicJobs.BlueOreCollector] < 2)
                    {
                        unit.LogicJob = Unit.LogicJobs.BlueOreCollector;
                        jobCount[(int)Unit.LogicJobs.BlueOreCollector]++;
                    }
                    else if (jobCount[(int)Unit.LogicJobs.RedOreCollector] < 2)
                    {
                        unit.LogicJob = Unit.LogicJobs.RedOreCollector;
                        jobCount[(int)Unit.LogicJobs.RedOreCollector]++;
                    }

                    else
                    {
                        unit.LogicJob = Unit.LogicJobs.Offense;
                        jobCount[(int)Unit.LogicJobs.Offense]++;
                    }
                    break;

                case "physicist":
                    jobCount[(int)unit.LogicJob]--;
                    if (jobCount[(int)Unit.LogicJobs.BlueiumProcessor] < 2)
                    {
                        unit.LogicJob = Unit.LogicJobs.BlueiumProcessor;
                        jobCount[(int)Unit.LogicJobs.BlueiumProcessor]++;
                    }
                    else if (jobCount[(int)Unit.LogicJobs.RediumProcessor] < 2)
                    {
                        unit.LogicJob = Unit.LogicJobs.RediumProcessor;
                        jobCount[(int)Unit.LogicJobs.RediumProcessor]++;
                    }
                    else
                    {
                        unit.LogicJob = Unit.LogicJobs.Offense;
                        jobCount[(int)Unit.LogicJobs.Offense]++;
                    }
                    break;

                case "manager":
                    jobCount[(int)unit.LogicJob]--;
                    if (jobCount[(int)Unit.LogicJobs.MaterialCollector] < 4)
                    {
                        unit.LogicJob = Unit.LogicJobs.MaterialCollector;
                        jobCount[(int)Unit.LogicJobs.MaterialCollector]++;
                    }
                    else if (jobCount[(int)Unit.LogicJobs.Offense] < 1)
                    {
                        unit.LogicJob = Unit.LogicJobs.Offense;
                        jobCount[(int)Unit.LogicJobs.Offense]++;
                    }
                    else
                    {
                        unit.LogicJob = Unit.LogicJobs.Defense;
                        jobCount[(int)Unit.LogicJobs.Defense]++;
                    }
                    break;
                default:
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Moves a unit.
        /// </summary>
        /// <param name="unit">unit to be moved.</param>
        /// <returns>True if unit has reached its target false else.</returns>
        private bool Move(Unit unit)
        {
            if (!CanAct(unit)) return false;
            if (unit.Moves <= 0) return false;
            if (unit.Target == null) return false;

            if (unit.Target.Machine != null && unit.Target.HasNeighbor(unit.Tile)) return true;
            if (unit.Tile == unit.Target) return true;

            Queue<Node<Tile>> path = new Queue<Node<Tile>>(FindPath(new[] { unit.Tile }, new[] { unit.Target }, GetNeighbors, GetCost(unit.Owner)));

            if (path.Count <= 0) return false;
            path.Dequeue();

            for (int k = unit.Moves; k > 0 && path.Any(); k--)
            {
                Tile move = path.Dequeue().Value;
                if (move.Unit != null || move.Machine != null)
                {
                    if (move.Unit != null && move.Unit.Owner == unit.Owner)
                    {
                        if (move.Unit.Moves > 0 && !move.Unit.Acted && move.Unit.StunTime <= 0)
                        {
                            if (move.Unit.Target != null)
                            {
                                Tile next = new Queue<Node<Tile>>(FindPath(new[] { unit.Tile }, new[] { unit.Target }, GetNeighbors, GetCost(unit.Owner))).FirstOrDefault()?.Value;
                                bool crossing = next != null && next == unit.Tile;
                                if (crossing)
                                {

                                    Unit whoMoves = move.Decoration != 1? move.Unit : unit;
                                    Unit whoDoesnt = move.Decoration == 1 ? move.Unit : unit;
                                    Tile oldTarget = whoMoves.Target;
                                    whoMoves.Target = whoMoves.Tile.GetNeighbors().FirstOrDefault(t => t.IsPathable());
                                    if (whoMoves.Target == null)
                                        return false;
                                    if (Move(whoMoves))
                                    {
                                        whoMoves.Target = oldTarget;
                                        return false;
                                    }

                                    whoMoves.Target = oldTarget;
                                    Move(whoDoesnt);

                                }
                                else
                                {
                                    if (!Move(move.Unit))
                                        return false;
                                }
                               
                            }
                            else
                            {
                                Tile next = move.GetNeighbors().FirstOrDefault(t => !t.IsWall && t.Unit == null && t.Machine == null);
                                if (next != null)
                                    move.Unit.Target = next;
                                if (!Move(move.Unit))
                                    return false;
                            }
                        }
                        else return false;
                    }
                    else
                        break;
                }
                

                unit.Move(move);
            }

            return unit.Target.HasNeighbor(unit.Tile) || unit.Target == unit.Tile;
        }

        public bool Attack(Unit unit)
        {
            if (!CanAct(unit)) return false;

            switch (unit.Job.Title)
            {
                    case "intern" :
                        unit.Target = Opponent.Units.FirstOrDefault(u => u.Job.Title == "physicist")?.Tile;
                        break;
                    case "physicist" :
                        unit.Target = Opponent.Units.FirstOrDefault(u => u.Job.Title == "manager")?.Tile;
                        break;
                    case "manager" :
                        unit.Target = Opponent.Units.FirstOrDefault(u => u.Job.Title == "intern")?.Tile;
                        break;
            }
            
            if (unit.Target == null)
                return false;

            if (Move(unit))
            {
                if (unit.Target.Unit?.StunImmune == 0)
                    unit.Act(unit.Target);
                else
                    unit.Attack(unit.Target);
                return true;
            }

            return false;
        }


        /// <summary>
        /// Gets the surounding tiles.
        /// </summary>
        /// <param name="tile">Tile from which to find neighbors</param>
        /// <returns>The surounding tiles if any.</returns>
        private IEnumerable<Tile> GetNeighbors(Tile tile)
        {
            // check to catch passing a null location. shouldn't happen but does.
            if (tile == null)
            {
                // Logger.Log("GetNeighbors Passed null tile.!", Logger.LogLevel.Error);
                return new HashSet<Tile>();
            }

            // get the list from the tile
            IEnumerable<Tile> t = tile.GetNeighbors();
            // IEnumerable<Tile> tx = new List<Tile>();

            // make sure the list is not null.
            if (t == null)
                return new HashSet<Tile>();
            // check to make sure no null tiles were given
            //TODO: Revisit this code. Maybe still return a partial list.
            return t.Any(ti => ti == null) ? new HashSet<Tile>() : t;
        }

        /// <summary>
        /// Gets the Cost function to be used by PathFinder.
        /// </summary>
        /// <param name="player">The player Trying to path.</param>
        /// <returns>Function that gives a tiles cost.</returns>
        private Func<Tile, Node<Tile>, float?> GetCost(Player player)
        {
            return player == Game.Players[0] ? (Func<Tile, Node<Tile>, float?>) GetCostPlayer0 : GetCostPlayer1;
        }

        /// <summary>
        /// Gets the Cost of a Tile from perspective of player 0
        /// </summary>
        /// <param name="tile">Tile from which to look at</param>
        /// <param name="node">Node which holds the tiles parent</param>
        /// <returns>The cost if valid tile, null if not a valid tile to move to.</returns>
        private float? GetCostPlayer0(Tile tile, Node<Tile> node)
        {
            var player = Game.Players[0];
            if (tile.Owner == player.Opponent)
                return null;
            if (tile.Unit != null)
            {
                if (tile.Unit.Owner != player)
                    return null;
                return 4;
            }
            if (tile.IsWall)
                return null;
            if (tile.Type == "generator" && tile.Owner != player)
                return null;
            if (tile.Machine != null)
                return null;
            return 1;
        }

        /// <summary>
        /// Gets the Cost of a Tile from perspective of player 1
        /// </summary>
        /// <param name="tile">Tile from which to look at</param>
        /// <param name="node">Node which holds the tiles parent</param>
        /// <returns>The cost if valid tile, null if not a valid tile to move to.</returns>
        private float? GetCostPlayer1(Tile tile, Node<Tile> node)
        {
            var player = Game.Players[1];
            if (tile.Owner == player.Opponent)
                return null;
            if (tile.Unit != null)
            {
                if (tile.Unit.Owner != player)
                    return null;
                return 4;
            }
            if (tile.IsWall)
                return null;
            if (tile.Type == "generator" && tile.Owner != player)
                return null;
            if (tile.Machine != null)
                return null;
            return 1;
        }
    }

}
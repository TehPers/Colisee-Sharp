﻿using System;
using System.IO;
using System.Linq;

namespace Joueur.cs.Games.Newtonian.Helpers
{
    public static class Logger
    {
        
        private static StreamWriter _file;
        public static string Path = "";
        private static string fileName = "logs/game.log"; 

        public enum LogLevel
        {
            Trace,
            Debug,
            Info,
            Warning,
            Error,
            None
        }

        public static bool Logging { get; private set; }
        public static LogLevel Level { get; set; } = LogLevel.Trace;


        public static void Log(string message, LogLevel level = LogLevel.Trace)
        {
            if (!Logger.Logging)
                return;

            if (Logger.Level > level)
                return;

            Console.WriteLine(message);
            _file.WriteLine(message);
        }

        public static void Open()
        {
            if(Logging)
                Close();

            Logging = true;
            int i = 0;
            if (Path != "" && Path.EndsWith('/'))
                Path = Path + '/';
            if (!Directory.Exists(Path+"logs"))
                Directory.CreateDirectory("logs/");
            while (File.Exists(fileName+(i == 0 ? "" :i.ToString())+".txt"))
                i++;
            try
            {
                _file = new StreamWriter(Path+fileName+(i == 0 ? "" : i.ToString())+".txt");

            }
            catch (IOException)
            {
                Logging = false;
                Open();
            }
        }

        public static void Close()
        {
            _file.Close();
            Logging = false;
        }
    }
}

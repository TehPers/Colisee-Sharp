﻿using Joueur.cs.Games.Pirates.Helpers;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using static Joueur.cs.Games.Pirates.Helpers.Pathfinder;

namespace Joueur.cs.Games.Pirates
{
    public class PirateLogic : UnitLogic<AI, Unit>
    {
        public Player Player => this.AI.Player;
        public Game Game => this.AI.Game;
        public Player Opponent => this.Player.Opponent;

        /// <summary>
        /// Ideal Amount of PKer Jobs
        /// </summary>
        private static int PkerCount => 5;

        /// <summary>
        /// Ideal Amount of Hunter Jobs
        /// </summary>
        private static int HunterCount => 5;

        /// <summary>
        /// Minimum Amount of Ships before allowing Jobs other than Hunter
        /// </summary>
        private static int MinShip => 4;

        /// <summary>
        /// Amount of gold to have before depositing.
        /// </summary>
        private static int GoldDeposit => 1000;


        public PirateLogic(AI ai) : base(ai) { }

        #region Defend
        //*******************Defend*******************
        /// <summary>
        /// Attempts to Attack a player who is charging.
        /// </summary>
        /// <param name="unit">Unit that is defending</param>
        /// <returns>True if action success</returns>
        public bool Defend(Unit unit)
        {
            HashSet<Tile> targets = (from u in Player.Opponent.Units
                where u.Tile != null && u.ShipHealth > 0 && u.Owner != unit.Owner
                select u.Tile).ToHashSet();
            Tile target = null;

            if (unit.ShipHealth <= 0 || unit.Acted) return false;

            if (!targets.Any()) return false;

            foreach (Tile tile in targets)
            {
                if (unit.Tile.InRange(tile, 5))
                {
                    target = tile;
                    break;
                }
            }

            if (target == null) return false;

            return (target?.Unit.Owner != null ? AttackPlayer(unit) : AttackMerchant(unit));
        }
        //********************************************
        #endregion

        #region Heal
        //********************Heal********************
        /// <summary>
        /// Attempts to heal if health reaches a certain point.
        /// </summary>
        /// <param name="unit">Unit in question.</param>
        /// <returns>True if action success</returns>
        public bool HealIfNeeded(Unit unit)
        {
            bool needHealing = false;

            needHealing = unit.ShipHealth <= 0 ? unit.CrewHealth < unit.Crew * 2 : unit.ShipHealth <= Game.ShipHealth / 2;

            if (needHealing)
            {
                Logger.Log($"{unit} needs healing!", Logger.LogLevel.Debug);
                HashSet<Tile> targets = new[] {Player.Port.Tile}.ToHashSet();
                if (!targets.Any(t => t.InRange(unit.Tile, this.Game.RestRange)))
                {
                    Queue<Node<Tile>> path = new Queue<Node<Tile>>(Pathfinder.FindPath(new[] { unit.Tile }, targets, this.GetNeighbors, this.GetCost(unit)));

                    if (!path.Any())
                        return false;

                    path.Dequeue();

                    while (unit.Moves > 0 && path.Any())
                        unit.Move(path.Dequeue().Value);
                }
                if(unit.Tile == null)
                    Logger.Log("Error: no tile", Logger.LogLevel.Error);
                if (targets.Any(t => t.InRange(unit.Tile, this.Game.RestRange)))
                {
                    if (unit.Gold > 0)
                        unit.Deposit();
                    ReFill(unit);
                    return unit.Rest();
                }
            }

            return false;
        }
        //********************************************
        #endregion

        #region DepositGold
        //*******************Deposit******************
        /// <summary>
        /// attempts to return gold if gold reaches a certain point.
        /// </summary>
        /// <param name="unit">Unit in question.</param>
        /// <returns>True if action success</returns>
        public bool DepositGold(Unit unit)
        {
            if (unit.Gold < GoldDeposit)
                return false;

            if (unit.ShipHealth <= 0 || unit.Acted)
                return false;

            HashSet<Tile> targets = new[] {unit.Owner.Port.Tile}.ToHashSet();

            if (!targets.Any())
                return false;
            if (!targets.Any(t => t.InRange(unit.Tile, 0)))
            {
                Queue<Node<Tile>> path = new Queue<Node<Tile>>(Pathfinder.FindPath(new[] { unit.Tile }, targets, this.GetNeighbors, this.GetCost(unit)));

                if (!path.Any())
                    return false;

                path.Dequeue();

                while (unit.Moves > 0 && path.Any())
                    unit.Move(path.Dequeue().Value);
            }

            if (unit.Tile == null)
                Logger.Log("Error: no tile", Logger.LogLevel.Error);

            if (targets.Any(t => t.InRange(unit.Tile, this.Game.RestRange)))
            {
                if (unit.Gold > 0)
                    unit.Deposit();
                ReFill(unit);
                return unit.Rest();
            }

            return false;
        }
        //********************************************
        #endregion

        #region CaptureShip
        //*******************Capture******************
        /// <summary>
        /// Attempts to Capture Ships.
        /// </summary>
        /// <param name="unit">Unit in question.</param>
        /// <returns>True if action success</returns>
        public bool CaptureShip(Unit unit)
        {

            if (unit.ShipHealth <= 0 || unit.Acted)
                return false;

            HashSet<Tile> targets = (from u in Game.Units
                                     where (u.Tile != null && u.Owner != unit.Owner && u.ShipHealth > 0 && u.Tile.Port == null)
                                     select u.Tile).ToHashSet();
            if (!targets.Any())
            {
                return false;
            }

            if (targets.Any(t => t.InRange(unit.Tile, 0)))
            {
                Tile target = unit.Tile?.GetNeighbors().Intersect(targets).FirstOrDefault();

                if (target == null)
                    return false;

                return target.Unit.Crew > 0 ? unit.Attack(target, "crew") : unit.Split(target, unit.Crew > 3 ? 2 : 1, -1);
            }

            if (!targets.Any(t => t.InRange(unit.Tile, 0)))
            {
                Queue<Node<Tile>> path = new Queue<Node<Tile>>(Pathfinder.FindPath(new []{unit.Tile}, targets, this.GetNeighbors, this.GetCost(unit)));
                if (!path.Any())
                    return false;
                path.Dequeue();
                while (unit.Moves > 0 && path.Any())
                {
                    Tile move = path.Dequeue().Value;
                    if(move.Unit == null)  
                        unit.Move(move);
                }
                if(unit.Tile == null)
                    Logger.Log("Error: Tile null", Logger.LogLevel.Error);
                Tile target = unit.Tile?.GetNeighbors().Intersect(targets).FirstOrDefault();
                if (target == null)
                    return false;

                return target.Unit.Crew > 0 ? unit.Attack(target, "crew") : unit.Split(target, unit.Crew > 3 ? 2 : 1, -1);
            }

            return false;
        }
        //********************************************
        #endregion

        #region AttackGold
        //***************AttackGold******************
        /// <summary>
        /// Attempts to Attack the ship with the highest gold
        /// </summary>
        /// <param name="unit">Unit in question.</param>
        /// <returns>True if action success</returns>
        public bool AttackGold(Unit unit)
        {
            Tile target;

            if (unit.ShipHealth <= 0 || unit.Acted)
                return false;
            HashSet<Tile> targets = (from u in Game.Units
                where (u.Tile != null && u.Gold > 0)
                select u.Tile).ToHashSet();
            Tile goldBoi = targets.FirstOrDefault();
            foreach (Tile tar in targets)
            {
                if (goldBoi?.Unit.Gold < tar.Unit.Gold)
                    goldBoi = tar;
            }
            if (goldBoi == null)
                return false;

            //attack if one is in range.
            if (goldBoi.InRange(unit.Tile, Game.ShipRange))
            {
                target = targets.FirstOrDefault(t => t.InRange(unit.Tile, Game.ShipRange));
                if (target != null)
                    unit.Attack(target, "ship");
            }

            if (!goldBoi.InRange(unit.Tile, 3))
            {
                Queue<Node<Tile>> path = new Queue<Node<Tile>>(Pathfinder.FindPath(new[] { unit.Tile }, new []{ goldBoi }, this.GetNeighbors, this.GetCost(unit)));
                if (!path.Any())
                    return false;
                path.Dequeue();
                while (unit.Moves > 0 && path.Any())
                {
                    Tile move = path.Dequeue().Value;
                    if(move.Unit == null)  
                        unit.Move(move);
                }
                if (unit.Tile == null)
                    Logger.Log("Error: Tile null", Logger.LogLevel.Error);
                target = goldBoi.InRange(unit.Tile, 3) ? goldBoi : null;
                if (target != null)
                    unit.Attack(target, "ship");
            }
            return true;
        }
        //********************************************
        #endregion

        #region AttackMerch
        //***************AttackMerch******************
        /// <summary>
        /// Attempts to attack nearest merchant
        /// </summary>
        /// <param name="unit">Unit in question.</param>
        /// <returns>True if action success</returns>
        public bool AttackMerchant(Unit unit)
        {
            Tile target;
            if (unit.ShipHealth <= 0 || unit.Acted)
                return false;
            HashSet<Tile> targets = (from u in Game.Units
                                     where (u.Tile != null && u.Owner == null && u.TargetPort != null && u.Crew > 0)
                                     select u.Tile).ToHashSet();
            if (!targets.Any())
                return false;

            //attack if one is in range.
            if (targets.Any(t => t.InRange(unit.Tile, Game.ShipRange)))
            {
                target = targets.FirstOrDefault(t => t.InRange(unit.Tile, Game.ShipRange));
                if (target != null)
                    unit.Attack(target, "ship");
            }

            if (!targets.Any(t => t.InRange(unit.Tile, Game.ShipRange)))
            {
                Queue<Node<Tile>> path = new Queue<Node<Tile>>(Pathfinder.FindPath(new []{unit.Tile}, targets, this.GetNeighbors, this.GetCost(unit)));
                if (!path.Any())
                    return false;
                path.Dequeue();
                while (unit.Moves > 0 && path.Any())
                {
                    Tile move = path.Dequeue().Value;
                    if (move.Unit == null)
                        unit.Move(move);
                }
                if (unit.Tile == null)
                    Logger.Log("Error: Tile null", Logger.LogLevel.Error);
                target = targets.FirstOrDefault(t => t.InRange(unit.Tile, Game.ShipRange));
                if (target != null)
                    unit.Attack(target, "ship");
            }
            return true;
        }
        //********************************************
        #endregion

        #region AttackPlayer
        //***************AttackPlayer*****************
        /// <summary>
        /// Attempts to attack a opponents ship.
        /// </summary>
        /// <param name="unit">Unit in question.</param>
        /// <returns>True if action success</returns>
        public bool AttackPlayer(Unit unit)
        {
            Tile target;
            //No ship or ship can't do anything.
            if (unit.ShipHealth <= 0 || unit.Acted)
                return false;

            //Find Targets to shoot at.
            HashSet<Tile> targets = (from u in Player.Opponent.Units
                                     where (u.Tile != null && u.Owner != unit.Owner  && u.ShipHealth > 0)
                                     select u.Tile).ToHashSet();
            //Check if there are any targets.
            if (!targets.Any())
                return false;

            //attack if one is in range.
            if (targets.Any(t => t.InRange(unit.Tile, Game.ShipRange)))
            {
                target = targets.FirstOrDefault(t => t.InRange(unit.Tile, Game.ShipRange));
                if (target != null)
                    unit.Attack(target, "ship");
            }
           
            //While they are not in range.
            if (!targets.Any(t => t.InRange(unit.Tile, Game.ShipRange)))
            {
                //Find a path to targets.
                Queue<Node<Tile>> path = new Queue<Node<Tile>>(Pathfinder.FindPath(new[] { unit.Tile }, targets, this.GetNeighbors, this.GetCost(unit)));
                //find possible target to set unit target
                Tile possibleTarget = Pathfinder
                    .FindPath(new[] {unit.Tile}, targets, this.GetNeighbors, this.GetCost(unit))
                    .FirstOrDefault(u => u.Value.Unit != null)?.Value;
                //check to make sure it has one.
                if (possibleTarget?.Unit != null)
                    unit.Target = possibleTarget;

                //checks for a valid path.
                if (!path.Any())
                    return false;

                //remove current location from path.
                path.Dequeue();

                //attempt to move while can.
                while (unit.Moves > 0 && path.Any())
                {
                    Tile move = path.Dequeue().Value;
                    if (move.Unit == null)
                        unit.Move(move);
                }

                //check to make sure the unit wasn't killed some how.
                if (unit.Tile == null)
                    Logger.Log("Error: Tile null", Logger.LogLevel.Error);

                //find target to shoot at.
               target = targets.FirstOrDefault(t => t.InRange(unit.Tile, Game.ShipRange));

                //attack if can.
                if (target != null)
                    unit.Attack(target, "ship");
            }
            return true;
        }
        //********************************************
        #endregion

        #region Refill
        //*****************Refill*********************
        /// <summary>
        /// Attempts to Refill crew on ship.
        /// </summary>
        /// <param name="unit">Unit in question.</param>
        /// <returns>True if action success</returns>
        public bool ReFill(Unit unit)
        {
            int oldCrew = unit.Crew;
            bool needUnits = oldCrew < 5;

            if (Player.Gold < Game.CrewCost)
                return false;
            if (needUnits)
            {
                HashSet<Tile> targets = new[] {Player.Port.Tile}.ToHashSet();
                if (!targets.Any())
                    return false;
                if (!targets.Any(t => t.InRange(unit.Tile, 0)))
                {
                    Queue<Node<Tile>> path = new Queue<Node<Tile>>(Pathfinder.FindPath(new[] { unit.Tile }, targets, this.GetNeighbors, this.GetCost(unit)));
                    if (path.Any())
                        return false;
                    if (!path.Any())
                        return false;

                    path.Dequeue();

                    while (unit.Moves > 0 && path.Any())
                        unit.Move(path.Dequeue().Value);
                }
                if (unit.Tile == null)
                    Logger.Log("Error: no tile", Logger.LogLevel.Error);
                if (targets.Any(t => t.InRange(unit.Tile, 0)))
                {
                    if (unit.Gold > 0)
                        unit.Deposit();
                    for (int k = 0; k < 5 - unit.Crew; k++)
                    {
                        if (!Player.Port.Spawn("crew"))
                            break;
                    }

                    return oldCrew < unit.Crew;
                }
            }
            
            return false;
        }
        //********************************************
        #endregion

        #region ForceJob
        //******************ForceJob******************
        /// <summary>
        /// Checks current jobs of ships and reassigns as necessary.
        /// </summary>
        /// <param name="unit">Unit in question.</param>
        /// <returns>True if action success</returns>
        public static bool ForceJob(Unit unit)
        {
            Pirates.Player player = unit.Owner;

            int pkCount = (from u in player.Units where u.Job == Unit.Jobs.PKer select u).Count();
            int huntCount = (from u in player.Units where u.Job == Unit.Jobs.Hunter select u).Count();
            int farmCount = (from u in player.Units where u.Job == Unit.Jobs.Farmer select u).Count();
            int shipCount = (from u in player.Units where u.ShipHealth > 0 select u).Count();
            int oppShipCount = (from u in player.Opponent.Units where u.ShipHealth > 0 select u).Count();

            if (shipCount > oppShipCount * 1.5)
            {
                unit.Job = Unit.Jobs.PKer;
                return true;
            }

            if (shipCount < oppShipCount && shipCount < MinShip)
            {
                unit.Job = Unit.Jobs.Hunter;
                return true;
            }
            switch (unit.Job)
            {
                case Unit.Jobs.Hunter:
                    if (player.Gold < 300 && shipCount < MinShip)
                    {
                        unit.Job = Unit.Jobs.Farmer;
                        return true;
                    }
                    if (shipCount > MinShip )
                    {
                    
                        unit.Job = Unit.Jobs.PKer;
                        return true;
                        
                       
                    }
                    break;
                case Unit.Jobs.PKer:
                    if (shipCount < MinShip)
                    {
                        unit.Job = Unit.Jobs.Hunter;
                        return true;
                    }
                    else if (pkCount > 3 && pkCount > farmCount && shipCount > oppShipCount * 1.5)
                    {
                        unit.Job = Unit.Jobs.Farmer;
                        return true;
                    }
                    break;
                case Unit.Jobs.Farmer:
                    if (shipCount < MinShip && player.Gold >= GoldDeposit )
                    {
                        unit.Job = Unit.Jobs.Hunter;
                        return true;
                    }
                    else if (farmCount > pkCount && shipCount < oppShipCount)
                    {
                        unit.Job = Unit.Jobs.PKer;
                        return true;
                    }
                    break;
                case Unit.Jobs.Defender:
                    return SetJob(unit);
                case Unit.Jobs.None:
                    return SetJob(unit);
                default:
                    return false;
            }

            return false;
        }
        //********************************************
        #endregion

        #region SetJob
        //******************SetJob******************
        /// <summary>
        /// Assigns a Job to a Unit.
        /// </summary>
        /// <param name="unit">Unit in question.</param>
        /// <returns>True if action success</returns>
        public static bool SetJob(Unit unit)
        {
            Pirates.Player player = unit.Owner;

            int pkCount = (from u in player.Units where u.Job == Unit.Jobs.PKer select u).Count();
            int huntCount = (from u in player.Units where u.Job == Unit.Jobs.Hunter select u).Count();
            int farmCount = (from u in player.Units where u.Job == Unit.Jobs.Farmer select u).Count();
            int shipCount = (from u in player.Units where u.ShipHealth > 0 select u).Count();
            int oppShipCount = (from u in player.Opponent.Units where u.ShipHealth > 0 select u).Count();
            
            if (shipCount > MinShip - 1)
            {
                if (huntCount >= MinShip - 1)
                {
                    if (pkCount > farmCount && shipCount > oppShipCount * 1.5)
                    {
                        unit.Job = Unit.Jobs.Farmer;
                    }
                    else
                    {
                        unit.Job = Unit.Jobs.PKer;
                    }
                }
                else
                {
                    unit.Job = Unit.Jobs.Hunter;
                }
            }
            else if (player.Gold <= GoldDeposit)
            {
                unit.Job = Unit.Jobs.Farmer;
            }
            else
            {
                unit.Job = Unit.Jobs.Hunter;
            }
             
            return true;
        }
        //********************************************
        #endregion

        #region GetNeighbors
        /// <summary>
        /// Gets the neighbors of the tile.
        /// </summary>
        /// <param name="tile">Tile in question</param>
        /// <returns>The list of Tiles</returns>
        private IEnumerable<Tile> GetNeighbors(Tile tile)
        {
            //check to catch passing a null location. shouldn't happen but does.
            if (tile == null)
            {
                Logger.Log("GetNeighbors Passed null tile.!", Logger.LogLevel.Error);
                return new HashSet<Tile>();
            }

            //get the list from the tile
            IEnumerable<Tile> t = tile.GetNeighbors();
            //make sure the list is not null.
            if (t == null)
                return new HashSet<Tile>();
            //check to make sure no null tiles were given
            foreach(Tile ti in t)
                if (ti == null)
                    return new HashSet<Tile>();
            return t;
        }
        #endregion

        private Func<Tile, Node<Tile>, float?> GetCost(Unit unit)
        {

            if (unit.ShipHealth > 0)
                return this.GetShipCost;
            return this.GetCrewCost;
        }

        private float? GetShipCost(Tile tile, Node<Tile> node)
        { 
            return (tile.Type != "water" ? null : GetCostBoth(tile, node));
        }

        private float? GetCrewCost(Tile tile, Node<Tile> node)
        {
            //crew can't walk on water 
            if (tile.Type != "land" && tile.Port?.Owner != Player)
                return null;

            if (tile.Unit.Owner != Player)
                return null;

            return GetCostBoth(tile, node);
        }

        private float? GetCostBoth(Tile tile, Node<Tile> node)
        {
            if (tile.Port != null && tile.Port?.Owner != Player && tile.Unit?.ShipHealth <= 0) 
                return null;
            if (tile.Unit != null)
                return 5;
            if (tile.GetNeighbors().Any(t => t.Unit != null && t.Unit.Owner == Opponent))
                return 10;

            return 1;
        }


    }
}

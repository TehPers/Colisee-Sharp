// This is where you build your AI for the Pirates game.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Joueur.cs.Games.Catastrophe;
using Joueur.cs.Games.Pirates.Helpers;
using static Joueur.cs.Games.Pirates.Helpers.Pathfinder;

// <<-- Creer-Merge: usings -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
// you can add additional using(s) here
// <<-- /Creer-Merge: usings -->>

namespace Joueur.cs.Games.Pirates
{
    /// <summary>
    /// This is where you build your AI for Pirates.
    /// </summary>
    public class AI : BaseAI
    {
        #region Properties
        #pragma warning disable 0169 // the never assigned warnings between here are incorrect. We set it for you via reflection. So these will remove it from the Error List.
        #pragma warning disable 0649
        /// <summary>
        /// This is the Game object itself. It contains all the information about the current game.
        /// </summary>
        public readonly Game Game;
        /// <summary>
        /// This is your AI's player. It contains all the information about your player's state.
        /// </summary>
        public readonly Player Player;
        #pragma warning restore 0169
        #pragma warning restore 0649


        // <<-- Creer-Merge: properties -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
        // you can add additional properties here for your AI to use
        private Player Opponent => this.Player.Opponent;
        private Port Port => Player.Port;
        private readonly int ForceJobCheck = 20;
        private int turnOffset = 0;
        private bool initialized = false;

        public int Crew => this.Player.Units.Sum(u => u.Crew);
        public int Ships => this.Player.Units.Count(u => u.ShipHealth > 0);

        private HashSet<Unit> playerUnits = new HashSet<Unit>();
        private HashSet<Unit> opponentUnits = new HashSet<Unit>();
        private HashSet<Unit> merchUnits = new HashSet<Unit>();


        /// <summary>
        /// The units that need to act still
        /// </summary>
        public Queue<Unit> UnitsToAct { get; } = new Queue<Unit>();
        /// <summary>
        /// List of jobs with their respective tasks.
        /// </summary>
        public Dictionary<Unit.Jobs, PirateLogic> Logic { get; }


        public static bool debug = true;


        // <<-- /Creer-Merge: properties -->>
        #endregion


        #region Methods
        /// <summary>
        /// This returns your AI's name to the game server. Just replace the string.
        /// </summary>
        /// <returns>Your AI's name</returns>
        public override string GetName()
        {
            // <<-- Creer-Merge: get-name -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
            return "A Dank Meme"; // REPLACE THIS WITH YOUR TEAM NAME!
            // <<-- /Creer-Merge: get-name -->>
        }

        /// <summary>
        /// This is automatically called when the game first starts, once the Game and all GameObjects have been initialized, but before any players do anything.
        /// </summary>
        /// <remarks>
        /// This is a good place to initialize any variables you add to your AI or start tracking game objects.
        /// </remarks>
        public override void Start()
        {
            Logger.Open();
            Console.Clear();
            // <<-- Creer-Merge: start -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
            base.Start();
            PirateLogic curr;

            //PKer Task List
            Logic.Add(Unit.Jobs.PKer,curr = new PirateLogic(this));
            curr.AddTask(curr.HealIfNeeded);
            curr.AddTask(curr.DepositGold);
            curr.AddTask(curr.AttackPlayer);
            curr.AddTask(curr.AttackMerchant);

            //Hunter Task List
            Logic.Add(Unit.Jobs.Hunter, curr = new PirateLogic(this));
            curr.AddTask(curr.ReFill);
            curr.AddTask(curr.DepositGold);
            curr.AddTask(curr.HealIfNeeded);
            curr.AddTask(curr.CaptureShip);

            //Farmer Task List
            Logic.Add(Unit.Jobs.Farmer, curr = new PirateLogic(this));
            curr.AddTask(curr.HealIfNeeded);
            curr.AddTask(curr.DepositGold);
            curr.AddTask(curr.AttackMerchant);
            curr.AddTask(curr.AttackGold);

            //None
            Logic.Add(Unit.Jobs.None, curr = new PirateLogic(this));
            curr.AddTask(PirateLogic.SetJob);

            // <<-- /Creer-Merge: start -->>
        }

        /// <summary>
        /// This is automatically called every time the game (or anything in it) updates.
        /// </summary>
        /// <remarks>
        /// If a function you call triggers an update, this will be called before that function returns.
        /// </remarks>
        public override void GameUpdated()
        {
            // <<-- Creer-Merge: game-updated -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
            base.GameUpdated();
            // <<-- /Creer-Merge: game-updated -->>
        }

        /// <summary>
        /// This is automatically called when the game ends.
        /// </summary>
        /// <remarks>
        /// You can do any cleanup of you AI here, or do custom logging. After this function returns, the application will close.
        /// </remarks>
        /// <param name="won">True if your player won, false otherwise</param>
        /// <param name="reason">A string explaining why you won or lost</param>
        public override void Ended(bool won, string reason)
        {
            // <<-- Creer-Merge: ended -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
            base.Ended(won, reason);
            if (Debugger.IsAttached)
                Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.Black;
            Logger.Close();
            // <<-- /Creer-Merge: ended -->>
        }


        /// <summary>
        /// This is called every time it is this AI.player's turn.
        /// </summary>
        /// <returns>Represents if you want to end your turn. True means end your turn, False means to keep your turn going and re-call this function.</returns>
        public bool RunTurn()
        {
            // <<-- Creer-Merge: runTurn -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
            //*****************Information**********************
            #region ScreenInfo
            DisplayMap();
            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.Black;
            playerUnits.Clear();
            opponentUnits.Clear();
            merchUnits.Clear();

            foreach (Unit unit in from u in Game.Units where u.Tile != null select  u)
            {
                if (unit.Owner == Player)
                    playerUnits.Add(unit);
                else if (unit.Owner == Opponent)
                    opponentUnits.Add(unit);
                else merchUnits.Add(unit);
            }
            Logger.Log($"--[ Turn {this.Game.CurrentTurn} / {this.Game.MaxTurns} ]--");
            Logger.Log($"Infamy: {this.Player.Infamy} vs. {this.Opponent.Infamy}");
            Logger.Log($"Gold: {this.Player.Gold} vs. {this.Opponent.Gold}");
            Logger.Log($"Player Units: ");
            foreach (Unit unit in playerUnits)
            {
                Logger.Log($"{unit.Id}: Type: {(unit.ShipHealth > 0 ? $"Ship SH: {unit.ShipHealth}" : $"Crew")} CS: {unit.Crew} CH: {unit.CrewHealth} Loc: ({unit.Tile.X}, {unit.Tile.Y}) Gold: {unit.Gold} Job: {unit.Job}");
            }

            Logger.Log($"Opponent Units: ");
            foreach (Unit unit in opponentUnits)
            {
                Logger.Log($"{unit.Id}: Type: {(unit.ShipHealth > 0 ? $"Ship, SH: {unit.ShipHealth}" : $"Crew")} CS: {unit.Crew} CH: {unit.CrewHealth} Loc: ({unit.Tile.X}, {unit.Tile.Y}) Gold: {unit.Gold}");
            }

            Logger.Log($"Merchant Units: ");
            foreach (Unit unit in merchUnits)
            {
                Logger.Log($"{unit.Id}: Type: {(unit.ShipHealth > 0 ? $"Ship, SH: {unit.ShipHealth}" : $"Crew")} CS: {unit.Crew} CH: {unit.CrewHealth} Loc: ({unit.Tile.X}, {unit.Tile.Y}) Gold: {unit.Gold}");
            }

            Logger.Log("Ports:");
            foreach (Port port in Game.Ports)
            {
                Logger.Log($"{(port.Owner == null ? "Merchant" : port.Owner.Name)}: ({port.Tile.X}, {port.Tile.Y})");
            }
            #endregion
            //**************************************************

            if (!initialized)
            {
                turnOffset = Game.CurrentTurn % 2;
                initialized = !initialized;
            }

            UnitsToAct.Clear();

            foreach (Unit unit in Player.Units)
                if (unit.Tile != null)
                    UnitsToAct.Enqueue(unit);
            while (UnitsToAct.Any())
            {
                Unit unit = UnitsToAct.Dequeue();
                if ((Game.CurrentTurn + turnOffset) % ForceJobCheck == 0)
                {
                    PirateLogic.ForceJob(unit);
                }

                if (unit.Job == Unit.Jobs.None) PirateLogic.SetJob(unit);

                foreach (var logic in Logic[unit.Job].Tasks)
                {
                    if (logic(unit))
                        break;
                }
            }

            if (Port.Tile.Unit != null && Port.Tile?.Unit.ShipHealth > 0 && Port.Tile?.Unit.Owner != Player)
            {
                for (int k = 0; k < 3; k++)
                {
                    if(!Port.Spawn("crew"))
                        break;

                }

            }

            if ((Port.Tile?.Unit == null || Port.Tile.Unit.ShipHealth <= 0) && Player.Gold > Game.ShipCost)
            {
                Port.Spawn("ship");
            }
            if ((Port.Tile?.Unit?.Crew ?? 0) < 4)
            {
                for (int k = 0; k < 4 - (Port.Tile?.Unit?.Crew ?? 0); k++)
                {
                    if (Player.Gold < Game.CrewCost)
                        break;
                    if (Player.Gold > Game.CrewCost && !Port.Spawn("crew"))
                        break;
                }
            }

            return true;
            // <<-- /Creer-Merge: runTurn -->>
        }

        // <<-- Creer-Merge: methods -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
        // you can add additional methods here for your AI to call

        public AI()
        {
            this.Logic = new Dictionary<Unit.Jobs, PirateLogic>();

        }

        private void DisplayMap()
        {
            Console.SetCursorPosition(0, 0);
            Console.BackgroundColor = ConsoleColor.White;
            Console.Write(new string(' ', this.Game.MapWidth + 2));
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine();
            for (int y = 0; y < this.Game.MapHeight; y++)
            {
                Console.BackgroundColor = ConsoleColor.White;
                Console.Write(' ');
                for (int x = 0; x < this.Game.MapWidth; x++)
                {
                    Tile t = this.Game.Tiles[y * this.Game.MapWidth + x];

                    // Background color
                    if (t.Port != null)
                    {
                        Console.BackgroundColor = t.Port.Owner == this.Player ? ConsoleColor.DarkGray : t.Port.Owner == null ? ConsoleColor.Black : ConsoleColor.DarkRed;
                    }
                    else if (t.Type == "land")
                    {
                        if (t.Decoration)
                            Console.BackgroundColor = ConsoleColor.DarkCyan;
                        else
                            Console.BackgroundColor = ConsoleColor.DarkGreen;
                    }
                    else
                    {
                        if (t.Decoration)
                            Console.BackgroundColor = ConsoleColor.DarkBlue;
                        else
                              Console.BackgroundColor = ConsoleColor.Blue;
                    }

                    // Character to display
                    char foreground = ' ';
                    Console.ForegroundColor = ConsoleColor.White;

                    // Tile specific stuff
                    if (t.Unit != null)
                    {
                        Console.ForegroundColor = t.Unit.Owner == this.Player ? ConsoleColor.Gray : t.Unit.Owner == null ? ConsoleColor.White : ConsoleColor.Red;
                        foreground = t.Unit.ShipHealth > 0 ? 'S' : 'C';
                    }
                    else if (t.Gold > 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        foreground = '$';
                    }
                    else if (false && this.Game.Units.Any(u => u.Path.Contains(t)))
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        foreground = '*';
                    }

                    Console.Write(foreground);
                }

                Console.BackgroundColor = ConsoleColor.White;
                Console.Write(' ');
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.Write(y);
                Console.WriteLine();
            }

            Console.BackgroundColor = ConsoleColor.White;
            Console.Write(new string(' ', this.Game.MapWidth + 2));
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine();

            // Clear everything past here
            int left = Console.CursorLeft;
            int top = Console.CursorTop;
            Console.Write(new string(' ', Math.Max(Console.WindowHeight, Console.WindowWidth * (Console.WindowHeight - top) - 1)));
            Console.SetCursorPosition(left, top);
        }
        // <<-- /Creer-Merge: methods -->>
        #endregion
    }
}

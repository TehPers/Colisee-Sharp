﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Joueur.cs.Games.Pirates.Helpers
{
    public static class Logger
    {
        public static bool Logging = true;
        public static LogLevel Level = LogLevel.Trace;
        private static StreamWriter _file;
        private static string fileName = "logs/game.log"; 
       public enum LogLevel
        {
            Trace,
            Debug,
            Info,
            Warning,
            Error
        }

        public static void Log(string message, LogLevel level = LogLevel.Trace)
        {
            if (!Logger.Logging)
                return;

            if (Logger.Level > level)
                return;

            Console.WriteLine(message);
            _file.WriteLine(message);
        }

        public static void Open()
        {
            int i = 0;
            if (!Directory.Exists("logs"))
                Directory.CreateDirectory("logs/");
            while (File.Exists(fileName+(i == 0 ? "" :i.ToString())))
                i++;
            
            _file = new StreamWriter(fileName+(i == 0 ? "" : i.ToString()));
        }

        public static void Close()
        {
            _file.Close();
        }
    }
}
